# Replacing the logo

Two files control the app's logo. Replace them with your own images, keeping **the same file names**, then rebuild (or just copy them next to `WinProteus.exe` into the `Assets` folder).

| File | Used for | Format |
|---|---|---|
| `Assets/logo.png` | Logo at the top left of the sidebar | PNG, square, transparent background, 256×256 or larger |
| `Assets/app.ico` | Window/taskbar icon and the icon of `WinProteus.exe` | ICO containing 16, 24, 32, 48, 64, 128 and 256 px sizes |

If `logo.png` is missing, a plain colored tile is shown instead. If `app.ico` is missing, the default icon is used.
Tip: create the `.ico` from your PNG with any converter (e.g. https://icoconvert.com) – keep all sizes in one file.
